<?php
if(isset($_SESSION['usuario'])){
?>
  <section>
      <div class="container-fluid">
        <div class="row mb-5">
          <div class="col-xl-10 col-lg-9 col-md-8 ml-auto">
            <div class="row align-items-center">
              <div class="col-xl-6 col-12 mb-4 mb-xl-0">
                <h4 class="text-muted text-center mb-3">Errores y aciertos totales</h4>                
                <iframe style="background: #FFFFFF;border: none;border-radius: 2px;box-shadow: 0 2px 10px 0 rgba(70, 76, 79, .2);" width="530" height="380" src="https://charts.mongodb.com/charts-project-0-lrtlp/embed/charts?id=5e00bca8-3127-4d0c-b759-964d9d8d1852&autoRefresh=60&theme=light"></iframe>
              </div>
              <div class="col-xl-6 col-12">
                <h4 class="text-muted text-center mb-3">Errores y aciertos por jugador</h4>                
                <iframe style="background: #FFFFFF;border: none;border-radius: 2px;box-shadow: 0 2px 10px 0 rgba(70, 76, 79, .2);" width="530" height="380" src="https://charts.mongodb.com/charts-project-0-lrtlp/embed/charts?id=ec1c92c1-18f0-4a54-b5fc-d429a443308e&autoRefresh=60&theme=light"></iframe>
              </div>
            </div>
          </div>
        </div>
      </div>
  </section>    
  
  <section>
      <div class="container-fluid">
        <div class="row mb-5">
          <div class="col-xl-10 col-lg-9 col-md-8 ml-auto">
            <div class="row align-items-center">
              <div class="col-xl-6 col-12 mb-4 mb-xl-0">
                <h4 class="text-muted text-center mb-3">Jugadores con el mayor número de errores</h4>                
                <iframe style="background: #FFFFFF;border: none;border-radius: 2px;box-shadow: 0 2px 10px 0 rgba(70, 76, 79, .2);" width="530" height="380" src="https://charts.mongodb.com/charts-project-0-lrtlp/embed/charts?id=b3cf5d72-e2cf-4efb-abd1-72fd56ac8650&autoRefresh=60&theme=light"></iframe>
              </div>
              <div class="col-xl-6 col-12">
              <h4 class="text-muted text-center mb-3">Partidas totales realizadas en cada módulo</h4>                
                <iframe style="background: #FFFFFF;border: none;border-radius: 2px;box-shadow: 0 2px 10px 0 rgba(70, 76, 79, .2);" width="530" height="380" src="https://charts.mongodb.com/charts-project-0-lrtlp/embed/charts?id=948e67f4-2a6a-4f02-a7f1-b6afbe605243&autoRefresh=60&theme=light"></iframe>                
              </div>
            </div>
          </div>
        </div>
      </div>
    </section>    
       
    <section>
      <div class="container-fluid">
        <div class="row">
          <div class="col-xl-10 col-lg-9 col-md-8 ml-auto">
            <div class="row mb-4 align-items-center">
              <div class="col-xl-6 col-12 mb-4 mb-xl-0">
              <h4 class="text-muted text-center mb-3">Evaluación de errores y aciertos en los módulos</h4>                
                <iframe style="background: #FFFFFF;border: none;border-radius: 2px;box-shadow: 0 2px 10px 0 rgba(70, 76, 79, .2);" width="530" height="380" src="https://charts.mongodb.com/charts-project-0-lrtlp/embed/charts?id=5a3bdf73-6500-42a6-9bd0-9893761e1074&autoRefresh=60&theme=light"></iframe>
              </div>
              <div class="col-xl-6 col-12">
                <h4 class="text-muted text-center mb-3">Puntaje máximo alcanzado por los jugadores en los módulos</h4>                
                <iframe style="background: #FFFFFF;border: none;border-radius: 2px;box-shadow: 0 2px 10px 0 rgba(70, 76, 79, .2);" width="530" height="380" src="https://charts.mongodb.com/charts-project-0-lrtlp/embed/charts?id=826c39ac-5175-4cab-8e55-4fcd42edad71&autoRefresh=60&theme=light"></iframe>                
              </div>
            </div>
          </div>
        </div>
      </div>
    </section>                   
    <section>
      <div class="container-fluid">
        <div class="row">
          <div class="col-xl-10 col-lg-9 col-md-8 ml-auto">
            <div class="row mb-4 align-items-center">
              <div class="col-xl-6 col-12 mb-4 mb-xl-0">
                <h4 class="text-muted text-center mb-3">Balance mensual de los jugadores en el módulo: "Suma - Nivel fácil"</h4>                
                <iframe style="background: #FFFFFF;border: none;border-radius: 2px;box-shadow: 0 2px 10px 0 rgba(70, 76, 79, .2);" width="530" height="380" src="https://charts.mongodb.com/charts-project-0-lrtlp/embed/charts?id=d0c92ff8-10ba-48d2-b5c6-9e1769befca1&autoRefresh=60&theme=light"></iframe>
              </div>
              <div class="col-xl-6 col-12">
                <h4 class="text-muted text-center mb-3">Balance mensual de los jugadores en el módulo: "Suma - Nivel intermedio"</h4>                
                <iframe style="background: #FFFFFF;border: none;border-radius: 2px;box-shadow: 0 2px 10px 0 rgba(70, 76, 79, .2);" width="530" height="380" src="https://charts.mongodb.com/charts-project-0-lrtlp/embed/charts?id=849b8283-81e8-47a0-a37b-0ef17f62910a&autoRefresh=60&theme=light"></iframe>
              </div>
            </div>
          </div>
        </div>
      </div>
    </section>        

    <section>
      <div class="container-fluid">
        <div class="row">
          <div class="col-xl-10 col-lg-9 col-md-8 ml-auto">
            <div class="row mb-4 align-items-center">
              <div class="col-xl-6 col-12 mb-4 mb-xl-0">
                <h4 class="text-muted text-center mb-3">Balance mensual de los jugadores en el módulo: "Suma - Nivel difícil"</h4>                
                <iframe style="background: #FFFFFF;border: none;border-radius: 2px;box-shadow: 0 2px 10px 0 rgba(70, 76, 79, .2);" width="530" height="380" src="https://charts.mongodb.com/charts-project-0-lrtlp/embed/charts?id=9ccaafb7-66d4-4c0a-8e82-0396e55739e1&autoRefresh=60&theme=light"></iframe>
              </div>
              <div class="col-xl-6 col-12">
                <h4 class="text-muted text-center mb-3">Balance mensual de los jugadores en el módulo: "Resta - Nivel fácil"</h4>                
                <iframe style="background: #FFFFFF;border: none;border-radius: 2px;box-shadow: 0 2px 10px 0 rgba(70, 76, 79, .2);" width="530" height="380" src="https://charts.mongodb.com/charts-project-0-lrtlp/embed/charts?id=0f8aaab6-4001-4277-9d13-553404b6fe87&autoRefresh=60&theme=light"></iframe>
              </div>
            </div>
          </div>
        </div>
      </div>
    </section>        

    <section>
      <div class="container-fluid">
        <div class="row">
          <div class="col-xl-10 col-lg-9 col-md-8 ml-auto">
            <div class="row mb-4 align-items-center">
              <div class="col-xl-6 col-12 mb-4 mb-xl-0">
                <h4 class="text-muted text-center mb-3">Balance mensual de los jugadores en el módulo: "Resta - Nivel intermedio"</h4>                
                <iframe style="background: #FFFFFF;border: none;border-radius: 2px;box-shadow: 0 2px 10px 0 rgba(70, 76, 79, .2);" width="530" height="380" src="https://charts.mongodb.com/charts-project-0-lrtlp/embed/charts?id=8212477e-b979-4066-87bd-2d4990a6fc2f&autoRefresh=60&theme=light"></iframe>
              </div>
              <div class="col-xl-6 col-12">
                <h4 class="text-muted text-center mb-3">Balance mensual de los jugadores en el módulo: "Resta - Nivel difícil"</h4>                
                <iframe style="background: #FFFFFF;border: none;border-radius: 2px;box-shadow: 0 2px 10px 0 rgba(70, 76, 79, .2);" width="530" height="380" src="https://charts.mongodb.com/charts-project-0-lrtlp/embed/charts?id=96ab3f9e-7365-40ab-9a57-a72f9006a72e&autoRefresh=60&theme=light"></iframe>
              </div>
            </div>
          </div>
        </div>
      </div>
    </section>        

    <section>
      <div class="container-fluid">
        <div class="row">
          <div class="col-xl-10 col-lg-9 col-md-8 ml-auto">
            <div class="row mb-4 align-items-center">
              <div class="col-xl-6 col-12 mb-4 mb-xl-0">
                <h4 class="text-muted text-center mb-3">Balance mensual de los jugadores en el módulo: "Multiplicación - Nivel fácil"</h4>                
                <iframe style="background: #FFFFFF;border: none;border-radius: 2px;box-shadow: 0 2px 10px 0 rgba(70, 76, 79, .2);" width="530" height="380" src="https://charts.mongodb.com/charts-project-0-lrtlp/embed/charts?id=6cd1911c-c94a-4ed0-b657-62bbe9702ed6&autoRefresh=60&theme=light"></iframe>
              </div>
              <div class="col-xl-6 col-12">
                <h4 class="text-muted text-center mb-3">Balance mensual de los jugadores en el módulo: "Multiplicación - Nivel intermedio"</h4>                
                <iframe style="background: #FFFFFF;border: none;border-radius: 2px;box-shadow: 0 2px 10px 0 rgba(70, 76, 79, .2);" width="530" height="380" src="https://charts.mongodb.com/charts-project-0-lrtlp/embed/charts?id=34d93926-f40f-450b-8c1d-84763d3b32cb&autoRefresh=60&theme=light"></iframe>
              </div>
            </div>
          </div>
        </div>
      </div>
    </section>        

    <section>
      <div class="container-fluid">
        <div class="row">
          <div class="col-xl-10 col-lg-9 col-md-8 ml-auto">
            <div class="row mb-4 align-items-center">
              <div class="col-xl-6 col-12 mb-4 mb-xl-0">
                <h4 class="text-muted text-center mb-3">Balance mensual de los jugadores en el módulo: "Multiplicación - Nivel difícil"</h4>                
                <iframe style="background: #FFFFFF;border: none;border-radius: 2px;box-shadow: 0 2px 10px 0 rgba(70, 76, 79, .2);" width="530" height="380" src="https://charts.mongodb.com/charts-project-0-lrtlp/embed/charts?id=7659118c-3bc8-4c52-b132-8d0466986a9b&autoRefresh=60&theme=light"></iframe>
              </div>
              <div class="col-xl-6 col-12">
                <h4 class="text-muted text-center mb-3">Balance mensual de los jugadores en el módulo: "División - Nivel fácil"</h4>                
                <iframe style="background: #FFFFFF;border: none;border-radius: 2px;box-shadow: 0 2px 10px 0 rgba(70, 76, 79, .2);" width="530" height="380" src="https://charts.mongodb.com/charts-project-0-lrtlp/embed/charts?id=56548b71-fe7f-40a7-b106-7ded181abc52&autoRefresh=60&theme=light"></iframe>
              </div>
            </div>
          </div>
        </div>
      </div>
    </section>

    <section>
      <div class="container-fluid">
        <div class="row">
          <div class="col-xl-10 col-lg-9 col-md-8 ml-auto">
            <div class="row mb-4 align-items-center">
              <div class="col-xl-6 col-12 mb-4 mb-xl-0">
                <h4 class="text-muted text-center mb-3">Balance mensual de los jugadores en el módulo: "División - Nivel intermedio"</h4>
                <iframe style="background: #FFFFFF;border: none;border-radius: 2px;box-shadow: 0 2px 10px 0 rgba(70, 76, 79, .2);" width="530" height="380" src="https://charts.mongodb.com/charts-project-0-lrtlp/embed/charts?id=55671d44-9697-4a81-9765-fd8ba1844772&autoRefresh=60&theme=light"></iframe>
              </div>
              <div class="col-xl-6 col-12">
                <h4 class="text-muted text-center mb-3">Balance mensual de los jugadores en el módulo: "División - Nivel difícil"</h4>
                <iframe style="background: #FFFFFF;border: none;border-radius: 2px;box-shadow: 0 2px 10px 0 rgba(70, 76, 79, .2);" width="530" height="380" src="https://charts.mongodb.com/charts-project-0-lrtlp/embed/charts?id=4f307970-9243-485b-871b-42d414b3bfca&autoRefresh=60&theme=light"></iframe>
              </div>
            </div>
          </div>
        </div>
      </div>
    </section>

<?php
}else
    header("location: index.php");
?>