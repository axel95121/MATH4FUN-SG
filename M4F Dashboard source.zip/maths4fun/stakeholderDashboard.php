<?php
if(isset($_SESSION['usuario'])){
?>
    <section>
      <div class="container-fluid">
        <div class="row">
          <div class="col-xl-10 col-lg-9 col-md-8 ml-auto">
            <div class="row mb-4 align-items-center">
              <div class="col-xl-6 col-12 mb-4 mb-xl-0">
                <h4 class="text-muted text-center mb-3">Balance de respuestas correctas e incorrectas por jugador</h4>                
                <iframe style="background: #FFFFFF;border: none;border-radius: 2px;box-shadow: 0 2px 10px 0 rgba(70, 76, 79, .2);" width="520" height="380" src="https://charts.mongodb.com/charts-project-0-lrtlp/embed/charts?id=cf899473-6b0d-45cf-84f4-44216ac3a0cc&autoRefresh=60&theme=light"></iframe>
              </div>
              <div class="col-xl-6 col-12">
                <h4 class="text-muted text-center mb-3">Media de tiempo en cada módulo por jugador</h4>                
                <iframe style="background: #FFFFFF;border: none;border-radius: 2px;box-shadow: 0 2px 10px 0 rgba(70, 76, 79, .2);" width="520" height="380" src="https://charts.mongodb.com/charts-project-0-lrtlp/embed/charts?id=27acc948-27fe-4726-b0a9-e936480dca0f&autoRefresh=60&theme=light"></iframe>
              </div>
            </div>
          </div>
        </div>
      </div>
    </section>        

    <section>
      <div class="container-fluid">
        <div class="row">
          <div class="col-xl-10 col-lg-9 col-md-8 ml-auto">
            <div class="row mb-4 align-items-center">
              <div class="col-xl-6 col-12 mb-4 mb-xl-0">
                <h4 class="text-muted text-center mb-3">Media de puntuación en cada módulo por jugador</h4>                
                <iframe style="background: #FFFFFF;border: none;border-radius: 2px;box-shadow: 0 2px 10px 0 rgba(70, 76, 79, .2);" width="520" height="380" src="https://charts.mongodb.com/charts-project-0-lrtlp/embed/charts?id=c6000245-7451-4146-9331-7d986e0a437a&autoRefresh=60&theme=light"></iframe>
              </div>
              <div class="col-xl-6 col-12 mb-4 mb-xl-0">
                <h4 class="text-muted text-center mb-3">Preguntas totales y respondidas por jugador</h4>                
                <iframe style="background: #FFFFFF;border: none;border-radius: 2px;box-shadow: 0 2px 10px 0 rgba(70, 76, 79, .2);" width="520" height="380" src="https://charts.mongodb.com/charts-project-0-lrtlp/embed/charts?id=6e604e83-f163-4f55-9578-f6c188347d49&autoRefresh=60&theme=light"></iframe>
              </div>              
            </div>
          </div>
        </div>
      </div>
    </section>   
    
    <section>
      <div class="container-fluid">
        <div class="row">
          <div class="col-xl-10 col-lg-9 col-md-8 ml-auto">
            <h4 class="text-muted text-center mb-3">Balance de preguntas respondidas y totales</h4>                
            <center><iframe style="background: #FFFFFF; border: none;border-radius: 2px;box-shadow: 0 2px 10px 0 rgba(70, 76, 79, .2);" width="880" height="450" src="https://charts.mongodb.com/charts-project-0-lrtlp/embed/charts?id=28c06ef8-4070-40b9-bd30-1add111cd483&autoRefresh=60&theme=light"></iframe></center>
          </div>                
        </div>
      </div>                
    </section>

    <br>

    <section>
      <div class="container-fluid">
        <div class="row">
          <div class="col-xl-10 col-lg-9 col-md-8 ml-auto">
          <h4 class="text-muted text-center mb-3">Media de tiempo invertido en cada módulo por sesión de juego</h4>
            <center><iframe style="background: #FFFFFF;border: none;border-radius: 2px;box-shadow: 0 2px 10px 0 rgba(70, 76, 79, .2);" width="880" height="450" src="https://charts.mongodb.com/charts-project-0-lrtlp/embed/charts?id=194591e9-a8df-4674-a075-2a2fe6b06725&autoRefresh=60&theme=light"></iframe></center>
          </div>                
        </div>
      </div>                
    </section>            

    <br>

    <section>
      <div class="container-fluid">
        <div class="row">
          <div class="col-xl-10 col-lg-9 col-md-8 ml-auto">
          <h4 class="text-muted text-center mb-3" align="center">Número de jugadores que han participado en cada módulo</h4>                
            <center><iframe style="background: #FFFFFF;border: none;border-radius: 2px;box-shadow: 0 2px 10px 0 rgba(70, 76, 79, .2);" width="880" height="450" src="https://charts.mongodb.com/charts-project-0-lrtlp/embed/charts?id=1c21dbe3-a33b-4f7e-b309-2b28e2c2291b&autoRefresh=60&theme=light"></iframe></center>
          </div>                
        </div>
      </div>                
    </section>                
<?php
}else
    header("location: index.php");
?>