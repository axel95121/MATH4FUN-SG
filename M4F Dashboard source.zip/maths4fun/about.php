<?php
  session_start();
  
  $inactividad = 600;
  // Comprobar si $_SESSION["timeout"] está establecida
  if(isset($_SESSION["timeout"])){
      // Calcular el tiempo de vida de la sesión (TTL = Time To Live)
      $sessionTTL = time() - $_SESSION["timeout"];
      if($sessionTTL > $inactividad){
          session_destroy();
          header("Location: logout.php");
      }
  }
  // El siguiente key se crea cuando se inicia sesión
  $_SESSION["timeout"] = time();
  if(isset($_SESSION['usuario'])){  
?>
<!doctype html>
<html lang="es">
  <head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">

    <link rel="title icon" href="images/logo.png">
    <link rel="stylesheet" href="css/bootstrap.css">
    <link rel="stylesheet" href="css/styles.css">
    <link rel="stylesheet" href="css/dashStyle.css">
    <link href="https://fonts.googleapis.com/css?family=Montserrat" rel="stylesheet">
    <link href="https://fonts.googleapis.com/css?family=Saira+Extra+Condensed:500,700" rel="stylesheet" type="text/css" />
    <link href="https://fonts.googleapis.com/css?family=Muli:400,400i,800,800i" rel="stylesheet" type="text/css" />    

    <title>Maths4Fun Dashboard</title>    

    <script src="https://use.fontawesome.com/releases/v5.13.0/js/all.js" crossorigin="anonymous"></script>    
    <script type="text/javascript">
        function logout(){            
            location.href = "logout.php";            
        }    
    </script>

  </head>
  <body>    
    <!-- Inicio de navbar -->
    <nav class="navbar navbar-expand-md navbar-light">
      <button class="navbar-toggler ml-auto mb-2 bg-light" type="button" data-toggle="collapse" data-target="#myNavbar">
        <span class="navbar-toggler-icon"></span>
      </button>
      <div class="collapse navbar-collapse" id="myNavbar">
        <div class="container-fluid">
          <div class="row">
            <!-- Inicio de sidebar -->
            <div class="col-xl-2 col-lg-3 col-md-4 sidebar fixed-top">
            <p class="navbar-brand text-white d-block mx-auto text-center py-3 mb-4 bottom-border">Maths4Fun</p>
              <div class="bottom-border pb-3">
                <center>
                  <img src="images/uestar.webp" width="125" height="150" aria-hidden="true" >                
                </center>                
              </div>
              <ul class="navbar-nav flex-column mt-4">
                <li class="nav-item"><a href="dashboard.php" class="nav-link text-white p-3 sidebar-link"><i class="fas fa-home text-light fa-lg mr-3"></i>Dashboard</a></li>
                <li class="nav-item"><a href="analytics.php" class="nav-link text-white p-3 sidebar-link"><i class="fas fa-chart-line text-light fa-lg mr-3"></i>Analítica indiv.</a></li>
                <li class="nav-item"><a href="players.php" class="nav-link text-white p-3 sidebar-link"><i class="fas fa-users text-light fa-lg mr-3"></i>Jugadores</a></li>
                <?php if ($_SESSION['rol'] == 'desarrollador') echo "<li class='nav-item'><a href='stakeholders.php' class='nav-link text-white p-3 sidebar-link'><i class='fas fa-user-friends text-light fa-lg mr-3'></i>Stakeholders</a></li>";?>
                <li class="nav-item"><a href="about.php" class="nav-link text-white p-3 current"><i class="fas fa-info-circle text-light fa-lg mr-3"></i>Acerca de</a></li>
                <li class="nav-item"><a href="contact.php" class="nav-link text-white p-3 sidebar-link"><i class="fas fa-envelope text-light fa-lg mr-3"></i>Contacto</a></li>                                
              </ul>
            </div>
            <!-- Fin de sidebar -->
             <!-- Inicio de top-nav -->
              <div class="col-xl-10 col-lg-9 col-md-8 ml-auto bg-dark fixed-top py-2 top-navbar">
                <div class="row align-items-center">
                  <div class="col-md-8">
                  <h4 class="text-light text-uppercase mb-0">Acerca de
                    </h4>
                  </div>                          
                  <div class="col-md-4">
                    <ul class="navbar-nav">                                                                     
                      <p id="username"><?php echo $_SESSION['usuario'] ?></p>                
                      <li class="nav-item ml-md-auto"><a href="#" class="nav-link" data-toggle="modal" data-target="#sign-out"><i class="fas fa-sign-out-alt text-danger fa-lg"></i></a></li>
                    </ul>          
                  </div>
              </div>
            <!-- Fin de top-nav -->
          </div>
        </div>
      </div>
    </nav>
    <!-- Fin de navbar -->        

     <!-- modal de cierre de sesión-->
    <div class="modal fade" id="sign-out">
      <div class="modal-dialog">
        <div class="modal-content">
          <div class="modal-header">
            <h4 class="modal-title">Cerrar sesión</h4>
            <button type="button" class="close" data-dismiss="modal">&times;</button>
          </div>
          <div class="modal-body">
            <p>Presione <font color="red">salir</font> para confirmar</p>            
          </div>
          <div class="modal-footer">
            <button type="button" class="btn btn-success" data-dismiss="modal">Mantenerme aquí</button>
            <button type="button" class="btn btn-danger" onclick="logout()">Salir</button>
          </div>
        </div>
      </div>
    </div>
    <!-- fin del modal -->    
    <br><br><br>
    <!-- Secciones de descripción -->    
    <div class="container-fluid p-0">            
      <section>
        <div class="container-fluid">
          <div class="row">
            <div class="col-xl-12 col-md-8 ml-auto">                                
              <center><img src="images/logo.jpeg" alt="Maths 4 Fun Logo" width="250"></center>
              <br>
              <p class="lead mb-0" style="text-align: justify;">El proyecto MATHS4FUN es un proyecto web sin fines de lucro cuyo principal objetivo es el de apoyar a los estudiantes de 5to grado EGB de la Unidad Educativa "Santo Tomás Apóstol Riobamba" (STAR) con el aprendizaje de las operaciones fundamentales de matemáticas. A su vez, permite a interesados (DOCENTES y DESARROLLADORES) en el proyecto a realizar un seguimiento de las actividades realizadas en el juego acorde a sus necesidades.</p>
            </div>
          </div>
        </div>      
      </section>            
      <br><hr><br>
      <section>
        <div class="container-fluid">
          <div class="row">
            <div class="col-xl-12 col-md-8 ml-auto">                
              <h2 class="mb-5">Desarrolladores</h2>
              <div class="d-flex flex-column flex-md-row justify-content-between mb-2">
                <div class="flex-grow-1">
                  <h3 class="mb-0">Brandon Alexander Tubón Usca</h3>
                  <div class="subheading mb-3">Estudiante</div>                            
                </div>
                <div class="flex-grow-1">
                  <h3 class="mb-0">Bryan Andrés Gagñay Angamarca</h3>
                  <div class="subheading mb-3">Estudiante</div>  
                </div>
              </div>                    
            </div>
          </div>
        </div>                
      </section>            
      <br><hr><br>
      <section>
        <div class="container-fluid">
          <div class="row mb-5">
            <div class="col-xl-12 col-md-8 ml-auto">                
              <div class="resume-section-content">
              <h2 class="mb-4">Tecnologías</h2>
              <div class="subheading mb-3">Lenguajes de Programación y herramientas empleadas</div>
                <ul class="list-inline dev-icons">
                  <li class="list-inline-item"><i class="fab fa-html5"></i></li>
                  <li class="list-inline-item"><i class="fab fa-css3-alt"></i></li>
                  <li class="list-inline-item"><i class="fab fa-js-square"></i></li>                        
                  <li class="list-inline-item"><i class="fab fa-php"></i></li>                            
                  <li class="list-inline-item"><img style="transform: translateY(-5px)" height="55" width="60" src="images/c-sharp.png"></li>                    
                  <li class="list-inline-item"><i class="fab fa-adobe"></i></li>                        
                  <li class="list-inline-item"><i class="fab fa-unity"></i></li>
                  <li class="list-inline-item"><img style="transform: translateY(-3px)" height="60" width="65" src="images/mongo.png"></li>
                </ul>                    
              </div>                      
            </div>
          </div>
        </div>                
      </section>             
    </div>             
    <!-- Fin de secciones de descripción -->
    <br>    
    <br><br>      
  </body>
  <!-- footer -->
  <footer>
      <div class="container-fluid">
        <div class="row">
          <div class="col-xl-10 col-lg-9 col-md-8 ml-auto">
            <div class="row border-top pt-3">
              <div class="col-lg-6 text-left">
                <p>&copy; 2020 Todos los derechos reservados</p>
              </div>
            </div>
          </div>
        </div>
      </div>
    </footer>
    <script src="https://code.jquery.com/jquery-3.5.1.js" integrity="sha256-QWo7LDvxbWT2tbbQ97B53yJnYU3WhH/C8ycbRAkjPDc=" crossorigin="anonymous"></script>
    <script src="https://cdnjs.cloudflare.com/ajax/libs/popper.js/1.14.3/umd/popper.min.js" integrity="sha384-ZMP7rVo3mIykV+2+9J3UJ46jBk0WLaUAdn689aCwoqbBJiSnjAK/l8WvCWPIPm49" crossorigin="anonymous"></script>
    <script src="https://stackpath.bootstrapcdn.com/bootstrap/4.1.1/js/bootstrap.min.js" integrity="sha384-smHYKdLADwkXOn1EmN1qk/HfnUcbVRZyYmZ4qpPea6sjB/pTJ0euyQp0Mk8ck+5T" crossorigin="anonymous"></script>        
    <script type="text/javascript" src="vendor/datatables/datatables.min.js"></script>        
    <script src="vendor/jquery-easing/jquery.easing.min.js"></script>    
    
    <!-- Fin de footer -->
  <?php
  }
  else{
    header("location: index.php");
  }?>
</html>