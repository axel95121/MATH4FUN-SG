<?php

require_once __DIR__ . '/vendor/autoload.php';    
$cliente = new MongoDB\Client("mongodb+srv://root:admin@cluster0-gfn3z.mongodb.net/users?retryWrites=true&w=majority");
$coleccion = $cliente->users->stakeholders;

$nombres = (isset($_POST['nombres'])) ? $_POST['nombres'] : '';
$apellidos = (isset($_POST['apellidos'])) ? $_POST['apellidos'] : '';
$correo = (isset($_POST['correo'])) ? $_POST['correo'] : '';
$genero = (isset($_POST['genero'])) ? $_POST['genero'] : '';
$rol = (isset($_POST['rol'])) ? $_POST['rol'] : '';
$opcion = (isset($_POST['opcion'])) ? $_POST['opcion'] : '';
$id = (isset($_POST['id'])) ? $_POST['id'] : '';
$json = "{}";

switch($opcion){
    case 1: //alta
        $contrasenia = password_hash($rol, PASSWORD_DEFAULT);
        $ingreso = $coleccion->insertOne([
            'nombres' => $nombres,
            'apellidos' => $apellidos,
            'correo' => $correo,
            'genero' => $genero,
            'rol' => $rol,
            'contrasenia' =>$contrasenia
        ]);        
        $cliente = null;
        print $json;
        break;

    case 2: //modificación

        $actualizacion = $coleccion->updateOne(['_id' => new \MongoDB\BSON\ObjectID($id)], 
        ['$set' => ['nombres' => $nombres,
                    'apellidos' => $apellidos,
                    'correo' => $correo,
                    'genero' => $genero,
                    'rol' => $rol,
        ]]);        
        $cliente = null;
        print $json;
        break;        

    case 3://baja
        $eliminacion = $coleccion->deleteOne(['_id' => new \MongoDB\BSON\ObjectID($id)]);        
        $cliente = null;
        print $json;
        break;        
}