    
$(document).ready( function(){          
    $(".loading-container").css('display', 'flex');          
    userIdCard = $.trim($("#userIdCard").val());
    $.get(
      "refreshData.php",
      { userIdCard: userIdCard},
      function(data){
        player = JSON.parse(data);        
          $('#preguntasr').html(player["preguntasr"]);
          $('#preguntast').html(player['preguntast']);
          $('#errores').html(player['errores']);
          $('#aciertos').html(player['aciertos']);
  
          $('#sfmin').html(player['sfmin']);
          $('#sfminf').html(player['sfminf']);              
          $('#sfmax').html(player['sfmax']);
          $('#sfmaxf').html(player['sfmaxf']);              
          $('#sfprom').html(player['sfprom']);
          $('#sfpar').html(player['sfpar']);
          $('#sfupar').html(player['sfupar']);
                
          $('#smmin').html(player['smmin']);
          $('#smminf').html(player['smminf']);              
          $('#smmax').html(player['smmax']);
          $('#smmaxf').html(player['smmaxf']);              
          $('#smprom').html(player['smprom']);
          $('#smpar').html(player['smpar']);
          $('#smupar').html(player['smupar']);
  
          $('#sdmin').html(player['sdmin']);
          $('#sdminf').html(player['sdminf']);              
          $('#sdmax').html(player['sdmax']);
          $('#sdmaxf').html(player['sdmaxf']);              
          $('#sdprom').html(player['sdprom']);
          $('#sdpar').html(player['sdpar']);
          $('#sdupar').html(player['sdupar']);
  
          $('#rfmin').html(player['rfmin']);
          $('#rfminf').html(player['rfminf']);              
          $('#rfmax').html(player['rfmax']);
          $('#rfmaxf').html(player['rfmaxf']);              
          $('#rfprom').html(player['rfprom']);
          $('#rfpar').html(player['rfpar']);
          $('#rfupar').html(player['rfupar']);
                
          $('#rmmin').html(player['rmmin']);
          $('#rmminf').html(player['rmminf']);             
          $('#rmmax').html(player['rmmax']);
          $('#rmmaxf').html(player['rmmaxf']);              
          $('#rmprom').html(player['rmprom']);
          $('#rmpar').html(player['rmpar']);
          $('#rmupar').html(player['rmupar']);
  
          $('#rdmin').html(player['rdmin']);
          $('#rdminf').html(player['rdminf']);              
          $('#rdmax').html(player['rdmax']);
          $('#rdmaxf').html(player['rdmaxf']);              
          $('#rdprom').html(player['rdprom']);
          $('#rdpar').html(player['rdpar']);
          $('#rdupar').html(player['rdupar']);
  
          $('#mfmin').html(player['mfmin']);
          $('#mfminf').html(player['mfminf']);              
          $('#mfmax').html(player['rmmax']);
          $('#mfmaxf').html(player['mfmaxf']);              
          $('#mfprom').html(player['mfprom']);
          $('#mfpar').html(player['mfpar']);
          $('#mfupar').html(player['mfupar']);
                
          $('#mmmin').html(player['mmmin']);
          $('#mmminf').html(player['mmminf']);              
          $('#mmmax').html(player['mmmax']);
          $('#mmmaxf').html(player['mmmaxf']);              
          $('#mmprom').html(player['mmprom']);
          $('#mmpar').html(player['mmpar']);
          $('#mmupar').html(player['mmupar']);
  
          $('#mdmin').html(player['mdmin']);
          $('#mdminf').html(player['mdminf']);              
          $('#mdmax').html(player['mdmax']);
          $('#mdmaxf').html(player['mdmaxf']);              
          $('#mdprom').html(player['mdprom']);
          $('#mdpar').html(player['mdpar']);
          $('#mdupar').html(player['mdupar']);
  
          $('#dfmin').html(player['dfmin']);
          $('#dfminf').html(player['dfminf']);              
          $('#dfmax').html(player['dfmax']);
          $('#dfmaxf').html(player['dfmaxf']);              
          $('#dfprom').html(player['dfprom']);
          $('#dfpar').html(player['dfpar']);
          $('#dfupar').html(player['dfupar']);
                
          $('#dmmin').html(player['dmmin']);
          $('#dmminf').html(player['dmminf']);              
          $('#dmmax').html(player['dmmax']);
          $('#dmmaxf').html(player['dmmaxf']);              
          $('#dmprom').html(player['dmprom']);
          $('#dmpar').html(player['dmpar']);
          $('#dmupar').html(player['dmupar']);
  
          $('#ddmin').html(player['ddmin']);
          $('#ddminf').html(player['ddminf']);              
          $('#ddmax').html(player['ddmax']);
          $('#ddmaxf').html(player['ddmaxf']);              
          $('#ddprom').html(player['ddprom']);
          $('#ddpar').html(player['ddpar']);
          $('#ddupar').html(player['ddupar']);

          $("#analytics-table td").each(function() {
            if ($(this).text() < 4) {
              $(this).css('color', 'red');
            }
            if ($(this).text() > 7) {
              $(this).css('color', 'green');
            }
          });                
          $(".circular").css('display', 'block');         
          $(".loading-container").css('display', 'none');
          $("#update-text").css('display', 'block');                                                
      }
    );    
    const numb = document.querySelector(".numb");
    let counter = 60;
    setInterval(()=>{        
      counter-=1;
      numb.textContent = counter;
      if(counter == 0){
        $(".circular").css('display', 'none');      
      }
    }, 1000);
    refrescaDatos();    
});

function refrescaDatos(){
    $(".loading-container").css('display', 'flex');
    $("#update-text").css('display', 'none');     
    $("#app").css('display', 'none');     
    userIdCard = $.trim($("#userIdCard").val());
    setTimeout( function(){
        $.get(
            "refreshData.php",
            { userIdCard: userIdCard},
            function(data){     
              player = JSON.parse(data);
              $('#preguntasr').html(player["preguntasr"]);
              $('#preguntast').html(player['preguntast']);
              $('#errores').html(player['errores']);
              $('#aciertos').html(player['aciertos']);
              
              $('#sfmin').html(player['sfmin']);
              $('#sfminf').html(player['sfminf']);              
              $('#sfmax').html(player['sfmax']);
              $('#sfmaxf').html(player['sfmaxf']);              
              $('#sfprom').html(player['sfprom']);
              $('#sfpar').html(player['sfpar']);
              $('#sfupar').html(player['sfupar']);
              
              $('#smmin').html(player['smmin']);
              $('#smminf').html(player['smminf']);              
              $('#smmax').html(player['smmax']);
              $('#smmaxf').html(player['smmaxf']);              
              $('#smprom').html(player['smprom']);
              $('#smpar').html(player['smpar']);
              $('#smupar').html(player['smupar']);

              $('#sdmin').html(player['sdmin']);
              $('#sdminf').html(player['sdminf']);              
              $('#sdmax').html(player['sdmax']);
              $('#sdmaxf').html(player['sdmaxf']);              
              $('#sdprom').html(player['sdprom']);
              $('#sdpar').html(player['sdpar']);
              $('#sdupar').html(player['sdupar']);

              $('#rfmin').html(player['rfmin']);
              $('#rfminf').html(player['rfminf']);              
              $('#rfmax').html(player['rfmax']);
              $('#rfmaxf').html(player['rfmaxf']);              
              $('#rfprom').html(player['rfprom']);
              $('#rfpar').html(player['rfpar']);
              $('#rfupar').html(player['rfupar']);
              
              $('#rmmin').html(player['rmmin']);
              $('#rmminf').html(player['rmminf']);              
              $('#rmmax').html(player['rmmax']);
              $('#rmmaxf').html(player['rmmaxf']);              
              $('#rmprom').html(player['rmprom']);
              $('#rmpar').html(player['rmpar']);
              $('#rmupar').html(player['rmupar']);

              $('#rdmin').html(player['rdmin']);
              $('#rdminf').html(player['rdminf']);              
              $('#rdmax').html(player['rdmax']);
              $('#rdmaxf').html(player['rdmaxf']);              
              $('#rdprom').html(player['rdprom']);
              $('#rdpar').html(player['rdpar']);
              $('#rdupar').html(player['rdupar']);

              $('#mfmin').html(player['mfmin']);
              $('#mfminf').html(player['mfminf']);              
              $('#mfmax').html(player['rmmax']);
              $('#mfmaxf').html(player['mfmaxf']);              
              $('#mfprom').html(player['mfprom']);
              $('#mfpar').html(player['mfpar']);
              $('#mfupar').html(player['mfupar']);
              
              $('#mmmin').html(player['mmmin']);
              $('#mmminf').html(player['mmminf']);              
              $('#mmmax').html(player['mmmax']);
              $('#mmmaxf').html(player['mmmaxf']);              
              $('#mmprom').html(player['mmprom']);
              $('#mmpar').html(player['mmpar']);
              $('#mmupar').html(player['mmupar']);

              $('#mdmin').html(player['mdmin']);
              $('#mdminf').html(player['mdminf']);              
              $('#mdmax').html(player['mdmax']);
              $('#mdmaxf').html(player['mdmaxf']);              
              $('#mdprom').html(player['mdprom']);
              $('#mdpar').html(player['mdpar']);
              $('#mdupar').html(player['mdupar']);

              $('#dfmin').html(player['dfmin']);
              $('#dfminf').html(player['dfminf']);              
              $('#dfmax').html(player['dfmax']);
              $('#dfmaxf').html(player['dfmaxf']);              
              $('#dfprom').html(player['dfprom']);
              $('#dfpar').html(player['dfpar']);
              $('#dfupar').html(player['dfupar']);
              
              $('#dmmin').html(player['dmmin']);
              $('#dmminf').html(player['dmminf']);              
              $('#dmmax').html(player['dmmax']);
              $('#dmmaxf').html(player['dmmaxf']);              
              $('#dmprom').html(player['dmprom']);
              $('#dmpar').html(player['dmpar']);
              $('#dmupar').html(player['dmupar']);

              $('#ddmin').html(player['ddmin']);
              $('#ddminf').html(player['ddminf']);              
              $('#ddmax').html(player['ddmax']);
              $('#ddmaxf').html(player['ddmaxf']);              
              $('#ddprom').html(player['ddprom']);
              $('#ddpar').html(player['ddpar']);
              $('#ddupar').html(player['ddupar']);              
              $("#analytics-table td").each(function() {
                if ($(this).text() < 4) {
                  $(this).css('color', 'red');
                }
                if ($(this).text() > 7) {
                  $(this).css('color', 'green');
                }
              });                            
              $(".circular").css('display', 'block');         
              $(".loading-container").css('display', 'none');
              $("#update-text").css('display', 'block');      
            }
         );         
         const numb = document.querySelector(".numb");
         let counter = 60;
         setInterval(()=>{        
           counter-=1;
           numb.textContent = counter;
           if(counter == 0){
             $(".circular").css('display', 'none');      
           }
         }, 1000);
         refrescaDatos();     
    }, 60000);    
}