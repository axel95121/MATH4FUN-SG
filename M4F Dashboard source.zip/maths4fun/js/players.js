$(document).ready(function(){
    tablaPersonas = $("#tablaPersonas").DataTable({
       "columnDefs":[{
        "targets": -1,
        "data":null,
        "defaultContent": "<div class='text-center'><div class='btn-group'><button class='btn btn-primary btnEditar'>Editar</button><button class='btn btn-danger btnBorrar'>Borrar</button></div></div>"  
       }],
        
    "language": {
            "lengthMenu": "Mostrar _MENU_ registros",
            "zeroRecords": "No se encontraron resultados",
            "info": "Mostrando registros del _START_ al _END_ de un total de _TOTAL_ registros",
            "infoEmpty": "Mostrando registros del 0 al 0 de un total de 0 registros",
            "infoFiltered": "(filtrado de un total de _MAX_ registros)",
            "sSearch": "Buscar:",
            "oPaginate": {
                "sFirst": "Primero",
                "sLast":"Último",
                "sNext":"Siguiente",
                "sPrevious": "Anterior"
             },
             "sProcessing":"Procesando...",
        }
    });
    
$("#btnNuevo").click(function(){
    $("#formPersonas").trigger("reset");
    $(".modal-header").css("background-color", "#1cc88a");
    $(".modal-header").css("color", "white");
    $(".modal-title").text("Nuevo Jugador");
    $("#modalCRUD").modal("show");
    id=null;
    opcion = 1; //alta
});
    
var fila; //capturar la fila para editar o borrar el registro
    
//botón EDITAR    
$(document).on("click", ".btnEditar", function(){
    fila = $(this).closest("tr");
    id = fila.find('td:eq(5)').text();    
    nombres = fila.find('td:eq(0)').text();
    apellidos = fila.find('td:eq(1)').text();
    cedula = fila.find('td:eq(2)').text();
    genero = fila.find('td:eq(3)').text();
    
    $("#nombres").val(nombres);
    $("#apellidos").val(apellidos);
    $("#cedula").val(cedula);
    //$("#genero").val(genero);
    switch(genero){
        case 'masculino':
        $("#masculino").prop("checked", true);
        break;
        default:
        $("#femenino").prop("checked", true);
        break;

    }        
    opcion = 2; //editar
    
    $(".modal-header").css("background-color", "#4e73df");
    $(".modal-header").css("color", "white");
    $(".modal-title").text("Editar Jugador");            
    $("#modalCRUD").modal("show");  
    
});

//botón BORRAR
$(document).on("click", ".btnBorrar", function(){
    fila = $(this);
    id = $(this).closest("tr").find('td:eq(5)').text();
    player = $(this).closest("tr").find('td:eq(0)').text()+" "+$(this).closest("tr").find('td:eq(1)').text();
    cedula = $(this).closest("tr").find('td:eq(2)').text()
    opcion = 3 //borrar
    var respuesta = confirm("¿Está seguro que desea eliminar a: "+player+" con CI: "+cedula+"?");
    if(respuesta){
        $.ajax({
            url: "playersCRUD.php",
            type: "POST",
            dataType: "json",
            data: {opcion:opcion, id:id},
            success: function(data){            
                location.reload();
            }        
        });        
    }   
});

//botón ENVIAR de los modales
$("#formPersonas").submit(function(e){
    e.preventDefault();    
    cedula = $.trim($("#cedula").val());
    if(validaCed(cedula)==1){        
        nombres = $.trim($("#nombres").val());
        apellidos = $.trim($("#apellidos").val());    
        genero = $.trim($("input[type='radio'][name='genero']:checked").val());

        $.ajax({
            url: "playersCRUD.php",
            type: "POST",
            dataType: "json",
            data: {nombres:nombres, apellidos:apellidos, cedula:cedula, genero:genero, id:id, opcion:opcion},
            success: function(data){            
                location.reload();
            }        
        });        
    }else{
        alert("La cédula ingresada no es válida!");
    }
    
});    
});

//Verificar cédula
function validaCed(ced)
{	
        if (ced.length == 10)
        {        	            
            var d = 0;
            var resultado;           
            var i, r, d, s = 0;
    		let v=[11];
            
            for (i = 1; i <= 10; i++)
            {
                v[i] = parseInt(ced[i-1]);                
            }
            
        	for (i = 1; i <= 9; i++)
        	{				            
            	if (i % 2 == 1)
            	{	        		
                	v[i] = v[i] * 2;                           
            	}
        	}                       

        	for (i = 1; i <= 9; i++)
        	{
            	if (v[i] > 9)
                v[i] = v[i] - 9;
        	}                        

        	for (i = 1; i <= 9; i++)
        	{
            	s = s + v[i];
        	}                        

        	r = s % 10;
        	if (r == 0)
            	d = 0;
        	else
            	d = 10 - r;        	                                    
            if (d == parseInt(ced[9]))
                resultado = 1;
            else
                resultado = 0;

            return resultado;
        }        
        return 0;
}

function valida(){                
    var cedu = document.getElementById("cedula").value;            
    var mensaje = document.getElementById("mensaje");

    if(validaCed(cedu) == 1){                
        mensaje.innerHTML = "Cédula válida";
        mensaje.style.color = "#00ff00";
    }else{        
        mensaje.innerHTML = "Cédula no válida";
        mensaje.style.color = "#ff0000";
    }

    if(cedu == ""){        
        mensaje.innerHTML = "";
        mensaje.style.color = "#00ff00";
    }
}