<?php    
    session_start();
    if(!isset($_SESSION['usuario'])){  
    require_once __DIR__ . '/vendor/autoload.php';    
    if(isset($_POST['enviar'])){
        $usuario = $_POST['usuario'];
        $contrasenia = $_POST['contrasenia'];
        $error = "";
        $exito = "";
    
        $cliente = new MongoDB\Client("mongodb+srv://root:admin@cluster0-gfn3z.mongodb.net/users?retryWrites=true&w=majority");
        $coleccion = $cliente->users->stakeholders;
        $documento = $coleccion->findOne(['correo' => $usuario]);
        if($documento!=null){
            if(password_verify($contrasenia, $documento['contrasenia'] ) != 0 ){
                $error = "";
                $_SESSION['usuario']=$documento['nombres'].' '.$documento['apellidos'];
                $_SESSION['rol']=$documento['rol'];                                
                if($_SESSION['rol'] != "admin")
                    header("location: dashboard.php");
                else
                    header("location: stakeholders.php");
            }else{
                $error = "La contraseña es errónea!";
                $exito = "";
            }
        }
        else{
            $error = "Usuario no encontrado!";
            $exito = "";
        }
    }
?>

<!doctype html>
<html lang="es">
<head>
    
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">        
    <link rel="stylesheet" href="css/bootstrap.css">        
    <link rel="stylesheet" href="css/indexStyle.css">

    <title>Maths4Fun | Bienvenido</title>

    <script type="text/javascript">
        function valida(){            
            
            var form = document.getElementById("form");
            var mail = document.getElementById("usuario").value;
            var patron = /^([a-z 0-9\.-]+)@([a-z0-9-]+).([a-z]{2,3})(.[a-z]{2,3})$/;            
            var mensaje = document.getElementById("mensaje");

            if(mail.match(patron)){
                
                form.classList.add("valid");
                form.classList.remove("invalid");
                mensaje.innerHTML = "Dirección de correo válida";
                mensaje.style.color = "#00ff00";
            }else{
                form.classList.remove("valid");
                form.classList.add("invalid");
                mensaje.innerHTML = "Dirección de correo inválida";
                mensaje.style.color = "#ff0000";
            }

            if(mail == ""){
                form.classList.remove("valid");
                form.classList.remove("invalid");
                mensaje.innerHTML = "";
                mensaje.style.color = "#00ff00";
            }
        }    
    </script>

</head>

<body>        
    <div class="d-flex justify-content-center align-items-center login-container">
        <form class="login-form text-center" method="post" id="form">            
            <img src="images/logo.jpeg" alt="Maths 4 Fun Logo" width="250">            
            <h1 class="mb-5 font-weight-light text-uppercase">Inicio de Sesión</h1>
            <?php if(isset($error)){ ?>    
            <p class="error" style="color:red;"><?php echo $error; ?></p>
            <?php }?>            
            <div class="form-group">
                <input type="text" onkeyup="valida()" class="form-control rounded-pill form-control-lg" name="usuario" id="usuario" placeholder="E-mail" required>
                <span id="mensaje"></span>
            </div>
            <div class="form-group">
                <input type="password" class="form-control rounded-pill form-control-lg" name="contrasenia" placeholder="Contraseña" required>
            </div>            
            <button type="submit" name="enviar" class="btn mt-5 rounded-pill btn-lg btn-custom btn-block text-uppercase">Ingresar</button>
            <p class="mt-3 font-weight-normal">No tiene una cuenta? Comuníquese al correo: <a href="mailto:info@uestar.edu.ec"><strong>info@uestar.edu.ec</strong></a></p>
        </form>
    </div>        
</body>
</html>
<?php
    }else{
        header("location: dashboard.php");      
    }
?>