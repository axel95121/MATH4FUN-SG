<?php
  session_start();    
  $inactividad = 600;
  // Comprobar si $_SESSION["timeout"] está establecida
  if(isset($_SESSION["timeout"])){
      // Calcular el tiempo de vida de la sesión (TTL = Time To Live)
      $sessionTTL = time() - $_SESSION["timeout"];
      if($sessionTTL > $inactividad){
          session_destroy();
          header("Location: logout.php");
      }
  }
  // El siguiente key se crea cuando se inicia sesión
  $_SESSION["timeout"] = time();

  if(isset($_SESSION['usuario']) && $_SESSION['rol'] == 'desarrollador' || $_SESSION['rol'] == 'admin'){  
?>
<!doctype html>
<html lang="es">
  <head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
    <link rel="title icon" href="images/logo.png">
    <link rel="stylesheet" href="css/bootstrap.css">        
    <link href="https://fonts.googleapis.com/css?family=Montserrat" rel="stylesheet">
    <link rel="stylesheet" href="css/dashStyle.css">
    <script defer src="https://use.fontawesome.com/releases/v5.0.13/js/all.js" integrity="sha384-xymdQtn1n3lH2wcu0qhcdaOpQwyoarkgLVxC/wZ5q7h9gHtxICrpcaSUfygqZGOe" crossorigin="anonymous"></script>
        
    <!--datables CSS básico-->
    <link rel="stylesheet" type="text/css" href="vendor/datatables/datatables.min.css"/>
    <!--datables estilo bootstrap 4 CSS-->  
    <link rel="stylesheet"  type="text/css" href="vendor/datatables/DataTables-1.10.18/css/dataTables.bootstrap4.min.css">      

    <title>Maths4Fun Dashboard</title>

    <script type="text/javascript">
        function logout(){            
            location.href = "logout.php";            
        }    
    </script>        
  </head>
  <body>
    
    <!-- Inicio de navbar -->
    <nav class="navbar navbar-expand-md navbar-light">
      <button class="navbar-toggler ml-auto mb-2 bg-light" type="button" data-toggle="collapse" data-target="#myNavbar">
        <span class="navbar-toggler-icon"></span>
      </button>
      <div class="collapse navbar-collapse" id="myNavbar">
        <div class="container-fluid">
          <div class="row">
            <!-- Inicio de sidebar -->
            <div class="col-xl-2 col-lg-3 col-md-4 sidebar fixed-top">
            <p class="navbar-brand text-white d-block mx-auto text-center py-3 mb-4 bottom-border">Maths4Fun</p>
              <div class="bottom-border pb-3">
                <center>
                  <img src="images/uestar.webp" width="125" height="150" aria-hidden="true" >                
                </center>                
              </div>
              <ul class="navbar-nav flex-column mt-4">
              <?php 
                if($_SESSION['rol'] == "admin")
                echo "<li class='nav-item'><a href='stakeholders.php' class='nav-link text-white p-3 current'><i class='fas fa-user-friends text-light fa-lg mr-3'></i>Stakeholders</a></li>";
                else{                
              ?>
                <li class="nav-item"><a href="dashboard.php" class="nav-link text-white p-3 sidebar-link"><i class="fas fa-home text-light fa-lg mr-3"></i>Dashboard</a></li>
                <li class="nav-item"><a href="analytics.php" class="nav-link text-white p-3 sidebar-link"><i class="fas fa-chart-line text-light fa-lg mr-3"></i>Analítica indiv.</a></li>
                <li class="nav-item"><a href="players.php" class="nav-link text-white p-3 sidebar-link"><i class="fas fa-users text-light fa-lg mr-3"></i>Jugadores</a></li>
                <li class="nav-item"><a href="stakeholders.php" class="nav-link text-white p-3 current"><i class="fas fa-user-friends text-light fa-lg mr-3"></i>Stakeholders</a></li>
                <li class="nav-item"><a href="about.php" class="nav-link text-white p-3 sidebar-link"><i class="fas fa-info-circle text-light fa-lg mr-3"></i>Acerca de</a></li>
                <li class="nav-item"><a href="contact.php" class="nav-link text-white p-3 sidebar-link"><i class="fas fa-envelope text-light fa-lg mr-3"></i>Contacto</a></li>                                
              <?php } ?>
              </ul>
            </div>
            <!-- Fin de sidebar -->
             <!-- Inicio de top-nav -->
             <div class="col-xl-10 col-lg-9 col-md-8 ml-auto bg-dark fixed-top py-2 top-navbar">
              <div class="row align-items-center">
                <div class="col-md-8">
                  <h4 class="text-light text-uppercase mb-0">Stakeholders                    
                  </h4>
                </div>                          
                <div class="col-md-4">
                  <ul class="navbar-nav">                                                                     
                    <p id="username"><?php echo $_SESSION['usuario'] ?></p>                
                    <li class="nav-item ml-md-auto"><a href="#" class="nav-link" data-toggle="modal" data-target="#sign-out"><i class="fas fa-sign-out-alt text-danger fa-lg"></i></a></li>
                  </ul>          
                </div>
            </div>
            <!-- Fin de top-nav -->
          </div>
        </div>
      </div>
    </nav>
    <!-- Fin de navbar -->        

     <!-- modal de cierre de sesión-->
     <div class="modal fade" id="sign-out">
      <div class="modal-dialog">
        <div class="modal-content">
          <div class="modal-header">
            <h4 class="modal-title">Cerrar sesión</h4>
            <button type="button" class="close" data-dismiss="modal">&times;</button>
          </div>
          <div class="modal-body">
            <p>Presione <font color="red">salir</font> para confirmar</p>            
          </div>
          <div class="modal-footer">
            <button type="button" class="btn btn-success" data-dismiss="modal">Mantenerme aquí</button>
            <button type="button" class="btn btn-danger" onclick="logout()">Salir</button>
          </div>
        </div>
      </div>
    </div>
    <!-- fin del modal -->
    <!--Modal para CRUD-->
    <div class="modal fade" id="modalCRUD" tabindex="-1" role="dialog" aria-labelledby="exampleModalLabel" aria-hidden="true">
        <div class="modal-dialog" role="document">
            <div class="modal-content">
                <div class="modal-header">
                    <h5 class="modal-title" id="exampleModalLabel"></h5>
                    <button type="button" class="close" data-dismiss="modal" aria-label="Close"><span aria-hidden="true">&times;</span>
                    </button>
                </div>
            <form id="formPersonas">    
                <div class="modal-body">

                    <div class="form-group">                    
                    <label for="nombre" class="col-form-label">Nombres:</label>
                    <input type="text" class="form-control" id="nombres" required>
                    </div>

                    <div class="form-group">                    
                    <label for="nombre" class="col-form-label">Apellidos:</label>
                    <input type="text" class="form-control" id="apellidos" required>
                    </div>

                    <div class="form-group">                    
                    <label for="correo" class="col-form-label">Correo:</label>
                    <input type="email" class="form-control" id="correo" required pattern="[a-z0-9._%+-]+@[a-z0-9.-]+\.[a-z]{2,}$" title="caracteres@caracteres.dominio">
                    </div>  

                    <div class="form-group">                    
                    <label for="genero" class="col-form-label">Género:</label><br>                    
                    <input type="radio" id="masculino" name="genero" value="masculino" required>
                    <label for="masculino">masculino</label><br>
                    <input type="radio" id="femenino" name="genero" value="femenino">
                    <label for="femenino">femenino</label><br>                    
                    </div>            

                    <div class="form-group">                    
                    <label for="genero" class="col-form-label">Rol:</label><br>                    
                    <input type="radio" id="docente" name="rol" value="docente" required>
                    <label for="docente">docente</label><br  >
                    <input type="radio" id="desarrollador" name="rol" value="desarrollador">
                    <label for="desarrollador">desarrollador</label><br>                    
                    <input type="radio" id="admin" name="rol" value="admin">
                    <label for="admin">admin de stakeholders</label><br>                    
                    </div>            

                </div>
                <div class="modal-footer">
                    <button type="button" class="btn btn-light" data-dismiss="modal">Cancelar</button>
                    <button type="submit" id="btnGuardar" class="btn btn-dark">Guardar</button>
                </div>
            </form>    
            </div>
        </div>
    </div>  
    <br><br><br>
        
    <section>
      <div class="container-fluid">
        <div class="row mb-5">
          <div class="col-xl-10 col-lg-9 col-md-8 ml-auto">

          <div class="container">
            <div class="row">
                <div class="col-lg-12">            
                <button id="btnNuevo" type="button" class="btn btn-success" data-toggle="modal">Nuevo</button>    
                </div>    
            </div>    
          </div>    
          <br>  
            <?php
            require_once __DIR__ . '/vendor/autoload.php';    
            $cliente = new MongoDB\Client("mongodb+srv://root:admin@cluster0-gfn3z.mongodb.net/users?retryWrites=true&w=majority");
            $coleccion = $cliente->users->stakeholders;
            $documento = $coleccion->find();
            ?>
          <div class="container">
                    <div class="row">
                            <div class="col-lg-12">
                                <div class="table-responsive">        
                                    <table id="tablaPersonas" class="table table-striped table-bordered table-condensed" style="width:100%">
                                    <thead class="text-center">
                                        <tr>                                            
                                            <th style='text-align:center'>Nombres</th>
                                            <th style='text-align:center'>Apellidos</th>
                                            <th style='text-align:center'>Correo</th>                                
                                            <th style='text-align:center'>Género</th>  
                                            <th style='text-align:center'>Rol</th>  
                                            <th style='text-align:center'>Almacenado</th>
                                            <th hidden>Id</th>
                                            <th style='text-align:center'>Acciones</th>                                            
                                        </tr>
                                    </thead>
                                    <tbody>
                                        <?php                            
                                        foreach($documento as $dat) {                                                        
                                        ?>
                                        <tr>
                                            <?php

                                                $timestamp = (new MongoDB\BSON\ObjectId($dat['_id']))->getTimestamp()*1000;
                                                $utcdatetime = new MongoDB\BSON\UTCDateTime($timestamp);
                                                $datetime = $utcdatetime->toDateTime();
                                                $utcEcuador = new DateInterval('PT5H');
                                                $datetime->sub($utcEcuador);
                                                $result = $datetime->format('Y-m-d H:i:s');
                                                //print_r($datetime);
                                            ?>
                                            
                                            <td style='text-align:center'><?php echo $dat['nombres'] ?></td>
                                            <td style='text-align:center'><?php echo $dat['apellidos'] ?></td>                                            
                                            <td style='text-align:center'><?php echo $dat['correo'] ?></td>    
                                            <td style='text-align:center'><?php echo $dat['genero'] ?></td>    
                                            <td style='text-align:center'><?php echo $dat['rol'] ?></td>    
                                            <td style='text-align:center'><?php echo $result?></td>
                                            <td hidden><?php echo $dat['_id'] ?></td>
                                            <td style='text-align:center'></td>                                            
                                        </tr>
                                        <?php
                                            }
                                        ?>                                
                                    </tbody>        
                                </table>                    
                                </div>
                            </div>
                    </div>  
          </div>    

          </div>
        </div>
      </div>      
    </section>    
           
    <!-- footer -->
    <footer>
      <div class="container-fluid">
        <div class="row">
          <div class="col-xl-10 col-lg-9 col-md-8 ml-auto">
            <div class="row border-top pt-3">
              <div class="col-lg-6 text-left">
                <p>&copy; 2020 Todos los derechos reservados</p>
              </div>
            </div>
          </div>
        </div>
      </div>
    </footer>
    <!-- Fin de footer -->
   
    <script src="https://code.jquery.com/jquery-3.5.1.js" integrity="sha256-QWo7LDvxbWT2tbbQ97B53yJnYU3WhH/C8ycbRAkjPDc=" crossorigin="anonymous"></script>
    <script src="https://stackpath.bootstrapcdn.com/bootstrap/4.1.1/js/bootstrap.min.js" integrity="sha384-smHYKdLADwkXOn1EmN1qk/HfnUcbVRZyYmZ4qpPea6sjB/pTJ0euyQp0Mk8ck+5T" crossorigin="anonymous"></script>        
    <script type="text/javascript" src="js/stakeholders.js"></script>  
    <script type="text/javascript" src="vendor/datatables/datatables.min.js"></script>        
    <script src="vendor/jquery-easing/jquery.easing.min.js"></script>
  </body>
  <?php
  }
  else{
    header("location: index.php");
  }?>
</html>