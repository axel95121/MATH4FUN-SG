<?php

require_once __DIR__ . '/vendor/autoload.php';    
$cliente = new MongoDB\Client("mongodb+srv://root:admin@cluster0-gfn3z.mongodb.net/users?retryWrites=true&w=majority");
$coleccion = $cliente->xapi->statements;
$userIdCard = (isset($_GET['userIdCard'])) ? $_GET['userIdCard'] : '';
$resp['preguntasr'] = 0;
$resp['preguntast'] = 0;
$resp['errores'] = 0;
$resp['aciertos'] = 0;

//-----------------------------------------Datos generales---------------------------------------------------------
$datos = $coleccion->find(['actor.idCard' => $userIdCard,'verb.display.en-US' => 'Completed']);
foreach($datos as $dat){    
    $resp['preguntasr'] += $dat['result']['attempts'];
    $resp['preguntast'] += 10;
    $resp['errores'] += ($dat['result']['attempts'] - $dat['result']['score']);
    $resp['aciertos'] += $dat['result']['score'];
}
//-----------------------------------------------------------------------------------------------------------------

//-----------------------------------------Suma Fácil----------------------------------------------------------------------------------------------------------------------------------------------------------------------------------
$ame = $coleccion->find(['actor.idCard' => $userIdCard, 'verb.display.en-US' => 'Completed', 'object.definition.name.en-US' => 'AdditionModule:Easy' ], ['sort' => ['timestamp' => -1], 'limit' => 1]);
foreach($ame as $dat) {
$resp['sfupar'] = $dat['timestamp']->toDateTime()->format('Y-m-d H:i:s');
}

$ameMin = $coleccion->find(['actor.idCard' => $userIdCard, 'verb.display.en-US' => 'Completed', 'object.definition.name.en-US' => 'AdditionModule:Easy' ], ['sort' => ['result.score' =>  1, 'timestamp' => 1], 'limit' => 1]);
$ameMax = $coleccion->find(['actor.idCard' => $userIdCard, 'verb.display.en-US' => 'Completed', 'object.definition.name.en-US' => 'AdditionModule:Easy' ], ['sort' => ['result.score' => -1, 'timestamp' => 1], 'limit' => 1]);

foreach($ameMin as $dat) {                                                        
$resp['sfmin'] = $dat['result']->score;
$resp['sfminf'] = $dat['timestamp']->toDateTime()->format('Y-m-d H:i:s');
}

foreach($ameMax as $dat) {                                                        
$resp['sfmax'] = $dat['result']->score;
$resp['sfmaxf'] = $dat['timestamp']->toDateTime()->format('Y-m-d H:i:s');
}

$pipeline = [
    [
        '$match' => [
            'object.definition.name.en-US' => 'AdditionModule:Easy'
        ]
    ],
    [
        '$match' => [
            'actor.idCard' => $userIdCard
        ]
    ],
    [
        '$group' => [
            '_id' => NULL,
            'promedio' => [
                '$avg' => '$result.score'
            ],
            'partidas' => [
                '$sum' => 1
            ]
        ]
    ]
];
$promedio = $coleccion->aggregate($pipeline);

foreach ($promedio as $prom) {
    $resp['sfprom'] = round($prom['promedio'],2);
    $resp['sfpar'] = $prom['partidas'];
}
//-------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------

//-----------------------------------------Suma Medio----------------------------------------------------------------------------------------------------------------------------------------------------------------------------------
$amm = $coleccion->find(['actor.idCard' => $userIdCard, 'verb.display.en-US' => 'Completed', 'object.definition.name.en-US' => 'AdditionModule:Medium' ], ['sort' => ['timestamp' => -1], 'limit' => 1]);
foreach($amm as $dat) {
$resp['smupar'] = $dat['timestamp']->toDateTime()->format('Y-m-d H:i:s');
}

$ammMin = $coleccion->find(['actor.idCard' => $userIdCard, 'verb.display.en-US' => 'Completed', 'object.definition.name.en-US' => 'AdditionModule:Medium' ], ['sort' => ['result.score' =>  1, 'timestamp' => 1], 'limit' => 1]);
$ammMax = $coleccion->find(['actor.idCard' => $userIdCard, 'verb.display.en-US' => 'Completed', 'object.definition.name.en-US' => 'AdditionModule:Medium' ], ['sort' => ['result.score' => -1, 'timestamp' => 1], 'limit' => 1]);

foreach($ammMin as $dat) {                                                        
$resp['smmin'] = $dat['result']->score;
$resp['smminf'] = $dat['timestamp']->toDateTime()->format('Y-m-d H:i:s');
}

foreach($ammMax as $dat) {                                                        
$resp['smmax'] = $dat['result']->score;
$resp['smmaxf'] = $dat['timestamp']->toDateTime()->format('Y-m-d H:i:s');
}

$pipeline = [
    [
        '$match' => [
            'object.definition.name.en-US' => 'AdditionModule:Medium'
        ]
    ],
    [
        '$match' => [
            'actor.idCard' => $userIdCard
        ]
    ],
    [
        '$group' => [
            '_id' => NULL,
            'promedio' => [
                '$avg' => '$result.score'
            ],
            'partidas' => [
                '$sum' => 1
            ]
        ]
    ]
];

$promedio = $coleccion->aggregate($pipeline);
foreach ($promedio as $prom) {
    $resp['smprom'] = round($prom['promedio'],2);
    $resp['smpar'] = $prom['partidas'];
}
//-------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------

//-----------------------------------------Suma Difícil----------------------------------------------------------------------------------------------------------------------------------------------------------------------------------
$amh = $coleccion->find(['actor.idCard' => $userIdCard, 'verb.display.en-US' => 'Completed', 'object.definition.name.en-US' => 'AdditionModule:Hard' ], ['sort' => ['timestamp' => -1], 'limit' => 1]);
foreach($amh as $dat) {
$resp['sdupar'] = $dat['timestamp']->toDateTime()->format('Y-m-d H:i:s');
}

$amhMin = $coleccion->find(['actor.idCard' => $userIdCard, 'verb.display.en-US' => 'Completed', 'object.definition.name.en-US' => 'AdditionModule:Hard' ], ['sort' => ['result.score' =>  1, 'timestamp' => 1], 'limit' => 1]);
$amhMax = $coleccion->find(['actor.idCard' => $userIdCard, 'verb.display.en-US' => 'Completed', 'object.definition.name.en-US' => 'AdditionModule:Hard' ], ['sort' => ['result.score' => -1, 'timestamp' => 1], 'limit' => 1]);

foreach($amhMin as $dat) {                                                        
$resp['sdmin'] = $dat['result']->score;
$resp['sdminf'] = $dat['timestamp']->toDateTime()->format('Y-m-d H:i:s');
}

foreach($amhMax as $dat) {                                                        
$resp['sdmax'] = $dat['result']->score;
$resp['sdmaxf'] = $dat['timestamp']->toDateTime()->format('Y-m-d H:i:s');
}

$pipeline = [
    [
        '$match' => [
            'object.definition.name.en-US' => 'AdditionModule:Hard'
        ]
    ],
    [
        '$match' => [
            'actor.idCard' => $userIdCard
        ]
    ],
    [
        '$group' => [
            '_id' => NULL,
            'promedio' => [
                '$avg' => '$result.score'
            ],
            'partidas' => [
                '$sum' => 1
            ]
        ]
    ]
];

$promedio = $coleccion->aggregate($pipeline);
foreach ($promedio as $prom) {
    $resp['sdprom'] = round($prom['promedio'],2);
    $resp['sdpar'] = $prom['partidas'];
}
//-------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------

//-----------------------------------------Resta Fácil----------------------------------------------------------------------------------------------------------------------------------------------------------------------------------
$sme = $coleccion->find(['actor.idCard' => $userIdCard, 'verb.display.en-US' => 'Completed', 'object.definition.name.en-US' => 'SubstractionModule:Easy' ], ['sort' => ['timestamp' => -1], 'limit' => 1]);
foreach($sme as $dat) {
$resp['rfupar'] = $dat['timestamp']->toDateTime()->format('Y-m-d H:i:s');
}

$smeMin = $coleccion->find(['actor.idCard' => $userIdCard, 'verb.display.en-US' => 'Completed', 'object.definition.name.en-US' => 'SubstractionModule:Easy' ], ['sort' => ['result.score' =>  1, 'timestamp' => 1], 'limit' => 1]);
$smeMax = $coleccion->find(['actor.idCard' => $userIdCard, 'verb.display.en-US' => 'Completed', 'object.definition.name.en-US' => 'SubstractionModule:Easy' ], ['sort' => ['result.score' => -1, 'timestamp' => 1], 'limit' => 1]);

foreach($smeMin as $dat) {                                                        
$resp['rfmin'] = $dat['result']->score;
$resp['rfminf'] = $dat['timestamp']->toDateTime()->format('Y-m-d H:i:s');
}

foreach($smeMax as $dat) {                                                        
$resp['rfmax'] = $dat['result']->score;
$resp['rfmaxf'] = $dat['timestamp']->toDateTime()->format('Y-m-d H:i:s');
}

$pipeline = [
    [
        '$match' => [
            'object.definition.name.en-US' => 'SubstractionModule:Easy'
        ]
    ],
    [
        '$match' => [
            'actor.idCard' => $userIdCard
        ]
    ],
    [
        '$group' => [
            '_id' => NULL,
            'promedio' => [
                '$avg' => '$result.score'
            ],
            'partidas' => [
                '$sum' => 1
            ]
        ]
    ]
];
$promedio = $coleccion->aggregate($pipeline);

foreach ($promedio as $prom) {
    $resp['rfprom'] = round($prom['promedio'],2);
    $resp['rfpar'] = $prom['partidas'];
}
//-------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------

//-----------------------------------------Resta Medio----------------------------------------------------------------------------------------------------------------------------------------------------------------------------------
$smm = $coleccion->find(['actor.idCard' => $userIdCard, 'verb.display.en-US' => 'Completed', 'object.definition.name.en-US' => 'SubstractionModule:Medium' ], ['sort' => ['timestamp' => -1], 'limit' => 1]);
foreach($smm as $dat) {
$resp['rmupar'] = $dat['timestamp']->toDateTime()->format('Y-m-d H:i:s');
}

$smmMin = $coleccion->find(['actor.idCard' => $userIdCard, 'verb.display.en-US' => 'Completed', 'object.definition.name.en-US' => 'SubstractionModule:Medium' ], ['sort' => ['result.score' =>  1, 'timestamp' => 1], 'limit' => 1]);
$smmMax = $coleccion->find(['actor.idCard' => $userIdCard, 'verb.display.en-US' => 'Completed', 'object.definition.name.en-US' => 'SubstractionModule:Medium' ], ['sort' => ['result.score' => -1, 'timestamp' => 1], 'limit' => 1]);

foreach($smmMin as $dat) {                                                        
$resp['rmmin'] = $dat['result']->score;
$resp['rmminf'] = $dat['timestamp']->toDateTime()->format('Y-m-d H:i:s');
}

foreach($smmMax as $dat) {                                                        
$resp['rmmax'] = $dat['result']->score;
$resp['rmmaxf'] = $dat['timestamp']->toDateTime()->format('Y-m-d H:i:s');
}

$pipeline = [
    [
        '$match' => [
            'object.definition.name.en-US' => 'SubstractionModule:Medium'
        ]
    ],
    [
        '$match' => [
            'actor.idCard' => $userIdCard
        ]
    ],
    [
        '$group' => [
            '_id' => NULL,
            'promedio' => [
                '$avg' => '$result.score'
            ],
            'partidas' => [
                '$sum' => 1
            ]
        ]
    ]
];
$promedio = $coleccion->aggregate($pipeline);

foreach ($promedio as $prom) {
    $resp['rmprom'] = round($prom['promedio'],2);
    $resp['rmpar'] = $prom['partidas'];
}
//-------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------

//-----------------------------------------Resta Difícil----------------------------------------------------------------------------------------------------------------------------------------------------------------------------------
$smh = $coleccion->find(['actor.idCard' => $userIdCard, 'verb.display.en-US' => 'Completed', 'object.definition.name.en-US' => 'SubstractionModule:Hard' ], ['sort' => ['timestamp' => -1], 'limit' => 1]);
foreach($smh as $dat) {
$resp['rdupar'] = $dat['timestamp']->toDateTime()->format('Y-m-d H:i:s');
}

$smhMin = $coleccion->find(['actor.idCard' => $userIdCard, 'verb.display.en-US' => 'Completed', 'object.definition.name.en-US' => 'SubstractionModule:Hard' ], ['sort' => ['result.score' =>  1, 'timestamp' => 1], 'limit' => 1]);
$smhMax = $coleccion->find(['actor.idCard' => $userIdCard, 'verb.display.en-US' => 'Completed', 'object.definition.name.en-US' => 'SubstractionModule:Hard' ], ['sort' => ['result.score' => -1, 'timestamp' => 1], 'limit' => 1]);

foreach($smhMin as $dat) {                                                        
$resp['rdmin'] = $dat['result']->score;
$resp['rdminf'] = $dat['timestamp']->toDateTime()->format('Y-m-d H:i:s');
}

foreach($smhMax as $dat) {                                                        
$resp['rdmax'] = $dat['result']->score;
$resp['rdmaxf'] = $dat['timestamp']->toDateTime()->format('Y-m-d H:i:s');
}

$pipeline = [
    [
        '$match' => [
            'object.definition.name.en-US' => 'SubstractionModule:Hard'
        ]
    ],
    [
        '$match' => [
            'actor.idCard' => $userIdCard
        ]
    ],
    [
        '$group' => [
            '_id' => NULL,
            'promedio' => [
                '$avg' => '$result.score'
            ],
            'partidas' => [
                '$sum' => 1
            ]
        ]
    ]
];
$promedio = $coleccion->aggregate($pipeline);

foreach ($promedio as $prom) {
    $resp['rdprom'] = round($prom['promedio'],2);
    $resp['rdpar'] = $prom['partidas'];
}
//-------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------

//-----------------------------------------Multiplicación Fácil----------------------------------------------------------------------------------------------------------------------------------------------------------------------------------
$mme = $coleccion->find(['actor.idCard' => $userIdCard, 'verb.display.en-US' => 'Completed', 'object.definition.name.en-US' => 'MultiplicationModule:Easy' ], ['sort' => ['timestamp' => -1], 'limit' => 1]);
foreach($mme as $dat) {
$resp['mfupar'] = $dat['timestamp']->toDateTime()->format('Y-m-d H:i:s');
}

$mmeMin = $coleccion->find(['actor.idCard' => $userIdCard, 'verb.display.en-US' => 'Completed', 'object.definition.name.en-US' => 'MultiplicationModule:Easy' ], ['sort' => ['result.score' =>  1, 'timestamp' => 1], 'limit' => 1]);
$mmeMax = $coleccion->find(['actor.idCard' => $userIdCard, 'verb.display.en-US' => 'Completed', 'object.definition.name.en-US' => 'MultiplicationModule:Easy' ], ['sort' => ['result.score' => -1, 'timestamp' => 1], 'limit' => 1]);

foreach($mmeMin as $dat) {                                                        
$resp['mfmin'] = $dat['result']->score;
$resp['mfminf'] = $dat['timestamp']->toDateTime()->format('Y-m-d H:i:s');
}

foreach($mmeMax as $dat) {                                                        
$resp['mfmax'] = $dat['result']->score;
$resp['mfmaxf'] = $dat['timestamp']->toDateTime()->format('Y-m-d H:i:s');
}

$pipeline = [
    [
        '$match' => [
            'object.definition.name.en-US' => 'MultiplicationModule:Easy'
        ]
    ],
    [
        '$match' => [
            'actor.idCard' => $userIdCard
        ]
    ],
    [
        '$group' => [
            '_id' => NULL,
            'promedio' => [
                '$avg' => '$result.score'
            ],
            'partidas' => [
                '$sum' => 1
            ]
        ]
    ]
];
$promedio = $coleccion->aggregate($pipeline);

foreach ($promedio as $prom) {
    $resp['mfprom'] = round($prom['promedio'],2);
    $resp['mfpar'] = $prom['partidas'];
}
//-------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------

//-----------------------------------------Multiplicación Medio----------------------------------------------------------------------------------------------------------------------------------------------------------------------------------
$mmm = $coleccion->find(['actor.idCard' => $userIdCard, 'verb.display.en-US' => 'Completed', 'object.definition.name.en-US' => 'MultiplicationModule:Medium' ], ['sort' => ['timestamp' => -1], 'limit' => 1]);
foreach($mmm as $dat) {
$resp['mmupar'] = $dat['timestamp']->toDateTime()->format('Y-m-d H:i:s');
}

$mmmMin = $coleccion->find(['actor.idCard' => $userIdCard, 'verb.display.en-US' => 'Completed', 'object.definition.name.en-US' => 'MultiplicationModule:Medium' ], ['sort' => ['result.score' =>  1, 'timestamp' => 1], 'limit' => 1]);
$mmmMax = $coleccion->find(['actor.idCard' => $userIdCard, 'verb.display.en-US' => 'Completed', 'object.definition.name.en-US' => 'MultiplicationModule:Medium' ], ['sort' => ['result.score' => -1, 'timestamp' => 1], 'limit' => 1]);

foreach($mmmMin as $dat) {                                                        
$resp['mmmin'] = $dat['result']->score;
$resp['mmminf'] = $dat['timestamp']->toDateTime()->format('Y-m-d H:i:s');
}

foreach($mmmMax as $dat) {                                                        
$resp['mmmax'] = $dat['result']->score;
$resp['mmmaxf'] = $dat['timestamp']->toDateTime()->format('Y-m-d H:i:s');
}

$pipeline = [
    [
        '$match' => [
            'object.definition.name.en-US' => 'MultiplicationModule:Medium'
        ]
    ],
    [
        '$match' => [
            'actor.idCard' => $userIdCard
        ]
    ],
    [
        '$group' => [
            '_id' => NULL,
            'promedio' => [
                '$avg' => '$result.score'
            ],
            'partidas' => [
                '$sum' => 1
            ]
        ]
    ]
];
$promedio = $coleccion->aggregate($pipeline);

foreach ($promedio as $prom) {
    $resp['mmprom'] = round($prom['promedio'],2);
    $resp['mmpar'] = $prom['partidas'];
}
//-------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------

//-----------------------------------------Resta Difícil----------------------------------------------------------------------------------------------------------------------------------------------------------------------------------
$mmh = $coleccion->find(['actor.idCard' => $userIdCard, 'verb.display.en-US' => 'Completed', 'object.definition.name.en-US' => 'MultiplicationModule:Hard' ], ['sort' => ['timestamp' => -1], 'limit' => 1]);
foreach($mmh as $dat) {
$resp['mdupar'] = $dat['timestamp']->toDateTime()->format('Y-m-d H:i:s');
}

$mmhMin = $coleccion->find(['actor.idCard' => $userIdCard, 'verb.display.en-US' => 'Completed', 'object.definition.name.en-US' => 'MultiplicationModule:Hard' ], ['sort' => ['result.score' =>  1, 'timestamp' => 1], 'limit' => 1]);
$mmhMax = $coleccion->find(['actor.idCard' => $userIdCard, 'verb.display.en-US' => 'Completed', 'object.definition.name.en-US' => 'MultiplicationModule:Hard' ], ['sort' => ['result.score' => -1, 'timestamp' => 1], 'limit' => 1]);

foreach($mmhMin as $dat) {                                                        
$resp['mdmin'] = $dat['result']->score;
$resp['mdminf'] = $dat['timestamp']->toDateTime()->format('Y-m-d H:i:s');
}

foreach($mmhMax as $dat) {                                                        
$resp['mdmax'] = $dat['result']->score;
$resp['mdmaxf'] = $dat['timestamp']->toDateTime()->format('Y-m-d H:i:s');
}

$pipeline = [
    [
        '$match' => [
            'object.definition.name.en-US' => 'MultiplicationModule:Hard'
        ]
    ],
    [
        '$match' => [
            'actor.idCard' => $userIdCard
        ]
    ],
    [
        '$group' => [
            '_id' => NULL,
            'promedio' => [
                '$avg' => '$result.score'
            ],
            'partidas' => [
                '$sum' => 1
            ]
        ]
    ]
];
$promedio = $coleccion->aggregate($pipeline);

foreach ($promedio as $prom) {
    $resp['mdprom'] = round($prom['promedio'],2);
    $resp['mdpar'] = $prom['partidas'];
}
//-------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------

//-----------------------------------------División Fácil----------------------------------------------------------------------------------------------------------------------------------------------------------------------------------
$dme = $coleccion->find(['actor.idCard' => $userIdCard, 'verb.display.en-US' => 'Completed', 'object.definition.name.en-US' => 'DivisionModule:Easy' ], ['sort' => ['timestamp' => -1], 'limit' => 1]);
foreach($dme as $dat) {
$resp['dfupar'] = $dat['timestamp']->toDateTime()->format('Y-m-d H:i:s');
}

$dmeMin = $coleccion->find(['actor.idCard' => $userIdCard, 'verb.display.en-US' => 'Completed', 'object.definition.name.en-US' => 'DivisionModule:Easy' ], ['sort' => ['result.score' =>  1, 'timestamp' => 1], 'limit' => 1]);
$dmeMax = $coleccion->find(['actor.idCard' => $userIdCard, 'verb.display.en-US' => 'Completed', 'object.definition.name.en-US' => 'DivisionModule:Easy' ], ['sort' => ['result.score' => -1, 'timestamp' => 1], 'limit' => 1]);

foreach($dmeMin as $dat) {                                                        
$resp['dfmin'] = $dat['result']->score;
$resp['dfminf'] = $dat['timestamp']->toDateTime()->format('Y-m-d H:i:s');
}

foreach($dmeMax as $dat) {                                                        
$resp['dfmax'] = $dat['result']->score;
$resp['dfmaxf'] = $dat['timestamp']->toDateTime()->format('Y-m-d H:i:s');
}

$pipeline = [
    [
        '$match' => [
            'object.definition.name.en-US' => 'DivisionModule:Easy'
        ]
    ],
    [
        '$match' => [
            'actor.idCard' => $userIdCard
        ]
    ],
    [
        '$group' => [
            '_id' => NULL,
            'promedio' => [
                '$avg' => '$result.score'
            ],
            'partidas' => [
                '$sum' => 1
            ]
        ]
    ]
];

$promedio = $coleccion->aggregate($pipeline);

foreach ($promedio as $prom) {
    $resp['dfprom'] = round($prom['promedio'],2);
    $resp['dfpar'] = $prom['partidas'];
}
//-------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------

//-----------------------------------------División Medio----------------------------------------------------------------------------------------------------------------------------------------------------------------------------------
$dmm = $coleccion->find(['actor.idCard' => $userIdCard, 'verb.display.en-US' => 'Completed', 'object.definition.name.en-US' => 'DivisionModule:Medium' ], ['sort' => ['timestamp' => -1], 'limit' => 1]);
foreach($dmm as $dat) {
$resp['dmupar'] = $dat['timestamp']->toDateTime()->format('Y-m-d H:i:s');
}

$dmmMin = $coleccion->find(['actor.idCard' => $userIdCard, 'verb.display.en-US' => 'Completed', 'object.definition.name.en-US' => 'DivisionModule:Medium' ], ['sort' => ['result.score' =>  1, 'timestamp' => 1], 'limit' => 1]);
$dmmMax = $coleccion->find(['actor.idCard' => $userIdCard, 'verb.display.en-US' => 'Completed', 'object.definition.name.en-US' => 'DivisionModule:Medium' ], ['sort' => ['result.score' => -1, 'timestamp' => 1], 'limit' => 1]);

foreach($dmmMin as $dat) {                                                        
$resp['dmmin'] = $dat['result']->score;
$resp['dmminf'] = $dat['timestamp']->toDateTime()->format('Y-m-d H:i:s');
}

foreach($dmmMax as $dat) {                                                        
$resp['dmmax'] = $dat['result']->score;
$resp['dmmaxf'] = $dat['timestamp']->toDateTime()->format('Y-m-d H:i:s');
}

$pipeline = [
    [
        '$match' => [
            'object.definition.name.en-US' => 'DivisionModule:Medium'
        ]
    ],
    [
        '$match' => [
            'actor.idCard' => $userIdCard
        ]
    ],
    [
        '$group' => [
            '_id' => NULL,
            'promedio' => [
                '$avg' => '$result.score'
            ],
            'partidas' => [
                '$sum' => 1
            ]
        ]
    ]
];
$promedio = $coleccion->aggregate($pipeline);

foreach ($promedio as $prom) {
    $resp['dmprom'] = round($prom['promedio'],2);
    $resp['dmpar'] = $prom['partidas'];
}
//-------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------

//-----------------------------------------Resta Difícil----------------------------------------------------------------------------------------------------------------------------------------------------------------------------------
$dmh = $coleccion->find(['actor.idCard' => $userIdCard, 'verb.display.en-US' => 'Completed', 'object.definition.name.en-US' => 'DivisionModule:Hard' ], ['sort' => ['timestamp' => -1], 'limit' => 1]);
foreach($dmh as $dat) {
$resp['ddupar'] = $dat['timestamp']->toDateTime()->format('Y-m-d H:i:s');
}

$dmhMin = $coleccion->find(['actor.idCard' => $userIdCard, 'verb.display.en-US' => 'Completed', 'object.definition.name.en-US' => 'DivisionModule:Hard' ], ['sort' => ['result.score' =>  1, 'timestamp' => 1], 'limit' => 1]);
$dmhMax = $coleccion->find(['actor.idCard' => $userIdCard, 'verb.display.en-US' => 'Completed', 'object.definition.name.en-US' => 'DivisionModule:Hard' ], ['sort' => ['result.score' => -1, 'timestamp' => 1], 'limit' => 1]);

foreach($dmhMin as $dat) {                                                        
$resp['ddmin'] = $dat['result']->score;
$resp['ddminf'] = $dat['timestamp']->toDateTime()->format('Y-m-d H:i:s');
}

foreach($dmhMax as $dat) {                                                        
$resp['ddmax'] = $dat['result']->score;
$resp['ddmaxf'] = $dat['timestamp']->toDateTime()->format('Y-m-d H:i:s');
}

$pipeline = [
    [
        '$match' => [
            'object.definition.name.en-US' => 'DivisionModule:Hard'
        ]
    ],
    [
        '$match' => [
            'actor.idCard' => $userIdCard
        ]
    ],
    [
        '$group' => [
            '_id' => NULL,
            'promedio' => [
                '$avg' => '$result.score'
            ],
            'partidas' => [
                '$sum' => 1
            ]
        ]
    ]
];
$promedio = $coleccion->aggregate($pipeline);

foreach ($promedio as $prom) {
    $resp['ddprom'] = round($prom['promedio'],2);
    $resp['ddpar'] = $prom['partidas'];
}
//-------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------

echo json_encode($resp);

?>